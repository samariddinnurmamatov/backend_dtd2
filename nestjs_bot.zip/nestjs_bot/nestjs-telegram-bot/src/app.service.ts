import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TaskEntity } from './task.entity';
import { Repository } from 'typeorm';

@Injectable()
export class AppService {
  constructor(
    @InjectRepository(TaskEntity)
    private readonly taskRepository: Repository<TaskEntity>,
  ) {}

  async getAll() {
    return this.taskRepository.find();
  }

  async getById(id: number) {
    return this.taskRepository.findOneBy({ id });
  }

  async createTask(name: string) {
    const task = await this.taskRepository.create({ name });
    if (!task) return null;

    // task.isCompleted = !task.isCompleted;
    await this.taskRepository.save(task);
    return this.getAll();
  }

  async doneTask(id: number) {
    const task = await this.getById(id);
    if (!task) return null;

    task.isCompleted = !task.isCompleted;
    await this.taskRepository.save(task);
    return this.getAll();
  }

  async editTask(id: number, name: string) {
    const task = await this.getById(id);
    if (!task) return null;

    task.name = name;
    await this.taskRepository.save(task);

    return this.getAll();
  }

  async deleteTask(id: number) {
    const task = await this.getById(id);
    if (!task) return null;

    await this.taskRepository.delete(task);

    return this.getAll();
  }
}

// mayli yaxshi qoling ishlarizga omad yaxshi ishlagizla
// bergan bilimzlariz uchun raxmat.  bergan bilimzlariz uchun rozi boling

// hizmatlar bo’lsa qilib beraman.

// o’rnimga bironta odam bo’lsa qarashib ham yuboraaman

// deganimdan keyin ha bo'ldim ketizmi kemaysizmi desa ha deymanda a

// bopti man ketadigan bo’layotgandim yaxshi qolizla ishalrizga omad
