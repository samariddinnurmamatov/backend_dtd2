// import { Controller, Get } from '@nestjs/common';
import { AppService } from './app.service';
import {
  Ctx,
  Hears,
  InjectBot,
  Message,
  On,
  Start,
  Update,
} from 'nestjs-telegraf';
import { Telegraf } from 'telegraf';
import { actionButtons } from './app.buttons';
import { Context } from './context.interface';
import { showList } from './app.utils';

// const todos = [
//   {
//     id: 1,
//     name: 'Buy goods',
//     isCompleted: false,
//   },
//   {
//     id: 2,
//     name: 'Go for a walk',
//     isCompleted: false,
//   },
//   {
//     id: 3,
//     name: 'Travel',
//     isCompleted: true,
//   },
// ];

@Update()
export class AppUpdate {
  constructor(
    @InjectBot() private readonly bot: Telegraf<Context>,
    private readonly appService: AppService,
  ) {}

  @Start()
  async startCommand(ctx: Context) {
    await ctx.reply('Hi! Friend ');
    await ctx.reply('What do you want to do', actionButtons());
  }

  @Hears('📋 Add Task List')
  async createTask(ctx: Context) {
    // const todos = await this.appService.getAll();
    ctx.session.type = 'create';
    await ctx.reply('Describe the task: ');
  }

  @Hears('📋 Task List')
  async getAll(ctx: Context) {
    const todos = await this.appService.getAll();
    await ctx.reply(showList(todos));
  }

  @Hears('✅ Done')
  async doneTask(ctx: Context) {
    ctx.session.type = 'done';
    await ctx.reply('Write the task ID: ');
  }

  @Hears('📝 Edit')
  async editTask(ctx: Context) {
    ctx.session.type = 'edit';
    await ctx.deleteMessage();
    await ctx.replyWithHTML(
      'Write a new name for the Task Id: \n\n' +
        'In format - <b>1 | New name</b>',
    );
  }

  @Hears('🗑️ Delete')
  async deleteTask(ctx: Context) {
    ctx.session.type = 'remove';
    await ctx.reply('Write the task ID: ');
  }

  @On('text')
  async getMessage(@Message('text') message: string, @Ctx() ctx: Context) {
    if (ctx.session.type === 'create') {
      const todos = await this.appService.createTask(message);

      // const taskId = Number(message);
      // const todo = todos.find((t) => t.id === taskId);

      if (!todos) {
        await ctx.deleteMessage();
        await ctx.reply('No task with this ID found');
        return;
      }

      // todo.isCompleted = !todo.isCompleted;
      // await ctx.reply(`Task marked as done: ${todo.name}`);
      await ctx.reply(showList(todos));
    }

    if (ctx.session.type === 'done') {
      const todos = await this.appService.doneTask(Number(message));

      // const taskId = Number(message);
      // const todo = todos.find((t) => t.id === taskId);

      if (!todos) {
        await ctx.deleteMessage();
        await ctx.reply('No task with this ID found');
        return;
      }

      // todo.isCompleted = !todo.isCompleted;
      // await ctx.reply(`Task marked as done: ${todo.name}`);
      await ctx.reply(showList(todos));
    }

    if (ctx.session.type === 'edit') {
      const [taskId, taskName] = message.split(' | ');
      // const todo = todos.find((t) => t.id === Number(taskId));

      const todos = await this.appService.editTask(Number(taskId), taskName);

      if (!todos) {
        await ctx.deleteMessage();
        await ctx.reply('No task with this ID found');
        return;
      }

      // todo.name = taskName;
      await ctx.reply(showList(todos));
    }

    if (ctx.session.type === 'remove') {
      // const taskId = Number(message);
      // const todoToRemove = todos.find((t) => t.id === taskId);
      const todos = await this.appService.deleteTask(Number(message));

      if (!todos) {
        await ctx.deleteMessage();
        await ctx.reply('No task with this ID found');
        return;
      }

      // todos.splice(todos.indexOf(todoToRemove), 1);
      await ctx.reply(showList(todos));
    }
  }
}
