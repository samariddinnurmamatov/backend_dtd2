import { Markup } from 'telegraf';

export function actionButtons() {
  return Markup.keyboard(
    [
      Markup.button.callback('📋 Add Task List', 'create'),
      Markup.button.callback('📋 Task List', 'list'),
      Markup.button.callback('✅ Done', 'done'),
      Markup.button.callback('📝 Edit', 'edit'),
      Markup.button.callback('🗑️ Delete', 'Delete'),
    ],
    {
      columns: 2,
    },
  );
}
