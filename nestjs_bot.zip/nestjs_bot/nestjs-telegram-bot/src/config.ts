export const TG_TOKEN = '6832158057:AAFyCCkslGPQfvay23FakWk4LoSR6muRlIg';
