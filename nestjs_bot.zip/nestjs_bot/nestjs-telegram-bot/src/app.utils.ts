export const showList = (todos) => {
  return `Your Task List:\n\n${todos
    .map((todo) => (todo.isCompleted ? '✅' : '🔘') + ' ' + todo.name)
    .join('\n\n')}`;
};
