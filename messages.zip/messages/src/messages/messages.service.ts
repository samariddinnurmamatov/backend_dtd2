import { Injectable, NotFoundException } from "@nestjs/common";
import { MessagesRepository } from "./messages.repository";

@Injectable()
export class MessagesService {
    constructor(public messagesRepo: MessagesRepository) {
        this.messagesRepo = messagesRepo;
    }
    
    // Service is creating its own dependencies oldin shunaqa edi
    // DONT THIS ON REAL APPS oldin shunaqa edi

    async findOne(id: string) {
        return this.messagesRepo.findOne(id);
    }

    findAll() {
        return this.messagesRepo.findAll();
    }

    create(content: string) {
        return this.messagesRepo.create(content)
    }

    async update(id: string, content: string) {
        const existingMessage = await this.messagesRepo.findOne(id);

        if (!existingMessage) {
            throw new NotFoundException("Message not found");
        }

        const updatedMessage = await this.messagesRepo.update(id, content);

        return updatedMessage;
    }

    async delete(id: string) {
        const deletedMessage = await this.messagesRepo.delete(id);

        if (!deletedMessage) {
            throw new NotFoundException("Message not found");
        }

        return deletedMessage;
    }
}

/// Run businees logic