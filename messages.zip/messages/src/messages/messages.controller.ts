import { Controller, Get, Post, Put, Delete, Body, Param, NotFoundException } from '@nestjs/common';
import { CreateMessageDto } from './dtos/create-message.dto';
import { MessagesService } from './messages.service';

@Controller('messages')
export class MessagesController {
    constructor(public messagesService: MessagesService) {}
    // DONT DO THIS REAL APP oldin shunaqa edi
    // USE DEPENDENCY INCEJTION  oldin shunaqa edi

    @Get()
    listMessages() {
        return this.messagesService.findAll();
    }

    @Post()
    createMessages(@Body() body: CreateMessageDto) {
        return this.messagesService.create(body.content);
    }

    @Get("/:id")
    async getMessages(@Param("id") id: string) {
        const message = await this.messagesService.findOne(id);

        if (!message) {
            throw new NotFoundException("message not found")
        }

        return message;
    }

    @Put("/:id")
    async updateMessage(@Param("id") id: string, @Body() body: CreateMessageDto) {
        const updatedMessage = await this.messagesService.update(id, body.content);

        if (!updatedMessage) {
            throw new NotFoundException("Message not found");
        }

        return updatedMessage;
    }

    @Delete("/:id")
    async deleteMessage(@Param("id") id: string) {
        const deletedMessage = await this.messagesService.delete(id);

        if (!deletedMessage) {
            throw new NotFoundException("Message not found");
        }

        return `Message with ID ${id} has been deleted`;
    }
}
